import assert from 'node:assert/strict'
import test from 'node:test'
import { maskedHref, maskSlug } from '../src/lib/linkmask-paths'
import { basePath } from '../src/lib/paths'

test('mask identifiers are stable, namespaced and safe for template IDs', () => {
  assert.equal(
    maskSlug('offer', 'garden-stones', 'shop'),
    'offer/i-garden-stones/i-shop',
  )
  assert.equal(maskSlug('program', '_shop'), 'program/i-_shop')
  assert.notEqual(maskSlug('deal', 'shop'), maskSlug('banner', 'shop'))
  for (const id of ['', '..', 'a/b', 'a b', 'a?b', 'https://shop.example'])
    assert.equal(maskSlug('program', id), undefined)
  assert.equal(maskSlug('program'), undefined)
})

test('masking only accepts paths and destinations supported by the redirect registry', () => {
  const slug = maskSlug('program', 'shop')
  const destination = 'https://shop.example/offer?paid=12345&pacid=example'
  assert.equal(
    maskedHref(slug, destination),
    `${basePath}/link/program/i-shop`,
  )
  assert.equal(maskedHref(undefined, destination), undefined)
  for (const target of [
    undefined,
    '',
    'javascript:alert(1)',
    'http://shop.example',
    'https:shop.example',
    'https:/shop.example',
    'https://secret@shop.example',
    'https://shop.example/æble',
    'https://shop.example/a b',
    'https://shop.example/\\item',
  ])
    assert.equal(maskedHref(slug, target), undefined)
  for (const path of [
    '//evil.example',
    'https://evil.example',
    '../shop',
    'program/a?url=evil',
  ])
    assert.equal(maskedHref(path, destination), undefined)
})
