import { randomUUID } from 'node:crypto';

function check(condition, message) {
  if (!condition) throw new Error(message);
}

function httpURL(value, label) {
  let url;
  try { url = new URL(value); } catch { throw new Error(`${label} must be an absolute HTTP(S) URL.`); }
  check(/^https?:\/\//i.test(value) && !/[^\x21-\x7e]|\\/.test(value) &&
    ['http:', 'https:'].includes(url.protocol) && !url.username && !url.password,
  `${label} must be an absolute HTTP(S) URL without credentials or whitespace.`);
  return url;
}

try {
  const args = process.argv.slice(2);
  check(args.length === 3, 'Usage: node verify.mjs <site-base-url> <slug> <expected-destination>');
  const [address, slug, destination] = args;
  const base = httpURL(address, 'Site base URL');
  check(!base.search && !base.hash, 'Site base URL must not contain a query or fragment.');
  check(/^[A-Za-z0-9][A-Za-z0-9_-]*(?:\/[A-Za-z0-9][A-Za-z0-9_-]*)*$/.test(slug),
    'Slug must contain slash-separated letters, numbers, hyphens or underscores.');
  httpURL(destination, 'Expected destination');
  base.pathname = `${base.pathname.replace(/\/$/, '')}/`;
  const link = new URL(`link/${slug}`, base);

  async function fetchLocal(url, method = 'GET') {
    // Never follow Location: verification must not generate affiliate visits.
    try {
      return await fetch(url, { method, redirect: 'manual', signal: AbortSignal.timeout(10_000) });
    } catch {
      throw new Error(`${method} request failed or timed out; confirm the site is running.`);
    }
  }

  async function verifyRedirect(url, method, label) {
    const response = await fetchLocal(url, method);
    check(response.status === 302, `${label}: expected HTTP 302.`);
    check(response.headers.get('location') === destination, `${label}: destination differs from expected.`);
    check(/(?:^|,)\s*no-store\s*(?:,|$)/i.test(response.headers.get('cache-control') ?? ''),
      `${label}: Cache-Control must include no-store.`);
    check(/(?:^|[,\s])noindex(?:$|[,\s])/i.test(response.headers.get('x-robots-tag') ?? ''),
      `${label}: X-Robots-Tag must include noindex.`);
    check(await response.text() === '', `${label}: redirect body must be empty.`);
  }

  await verifyRedirect(link, 'GET', 'GET');
  await verifyRedirect(link, 'HEAD', 'HEAD');
  const injected = new URL(link);
  injected.searchParams.set('url', 'https://example.invalid/override');
  injected.searchParams.set('paid', 'override');
  await verifyRedirect(injected, 'GET', 'Query override');

  const missing = await fetchLocal(new URL(`link/linkmask-missing-${randomUUID()}`, base));
  check(missing.status === 404 && !missing.headers.has('location'), 'Unknown slug: expected HTTP 404 without Location.');
  await missing.body?.cancel();
  const post = await fetchLocal(link, 'POST');
  check(post.status === 405 && !post.headers.has('location'), 'POST: expected HTTP 405 without Location.');
  await post.body?.cancel();
  console.log('LinkMask verified: GET, HEAD, query isolation, unknown slug, and POST.');
} catch (error) {
  console.error(`LinkMask verification failed: ${error.message}`);
  process.exitCode = 1;
}
