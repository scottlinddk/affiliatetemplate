# Use LinkMask with affiliatetemplate

This opt-in recipe adds same-origin affiliate redirects to a **server deployment**
of [affiliatetemplate](https://github.com/scottlinddk/affiliatetemplate).
It targets template revision
[`6360cbf`](https://github.com/scottlinddk/affiliatetemplate/tree/6360cbfa5a0bc25722d94d3612a5c6bac0e687f4)
(Next.js 16.3.6, React 19.3, Node.js 22 or newer). The original template repository
does not need to change until you choose to install the integration.

After affiliate consent, a product button's `href` becomes, for example,
`/link/offer/i-garden-table/i-offer-123`. Clicking it returns **HTTP 302** with the
configured affiliate URL in `Location`. Before consent, and immediately after
withdrawing consent, the button retains the direct merchant URL.

## Hosting requirement

Run the template with `npm run build` and `npm start`, or an equivalent Next.js
server host. Do not copy this dynamic route into a project that you deploy using
`npm run generate`, `STATIC_EXPORT=true`, or the template's GitHub Pages workflow.
Static HTML hosting cannot return this HTTP 302 response. LinkMask does not
replace it with JavaScript or a meta refresh.

For a static storefront, keep its current export workflow and direct links.
To use the same hostname for masked links, configure a redirect-capable edge or
reverse proxy to serve `/link/*` from a separate LinkMask server and all other
paths from the static host. That server needs its own approved destination
registry. GitHub Pages alone cannot provide this route. Only enable masked button
paths after that route exists.

## Install and copy the server recipe

After the first npm release, install from your template checkout:

```sh
npm install @scttlnd/linkmask
```

Commit `package.json` and `package-lock.json` so `npm ci` uses the same version on
your deployment host. Package downloads from npm do not require access to this
private GitHub repository.

Before the first publication, or when testing an unreleased change, run `npm pack`
in the LinkMask checkout and use a local archive instead:

```sh
mkdir vendor
cp ../LinkMask/scttlnd-linkmask-1.0.1.tgz vendor/
npm install ./vendor/scttlnd-linkmask-1.0.1.tgz
```

For archive installations, also commit the archive so deployment can find it.
No extra runtime service is needed for this Next.js integration. Package
maintainers can follow the [GitHub Actions publishing guide](publishing.md).

Copy the files below from `node_modules/@scttlnd/linkmask/examples/affiliatetemplate/src/`
to the corresponding paths under your template's `src/`:

| Example file                    | Purpose                                                                             |
| ------------------------------- | ----------------------------------------------------------------------------------- |
| `lib/linkmask-paths.ts`         | Browser-safe slug and href helpers; includes the template's base path.              |
| `lib/linkmask-registry.ts`      | Server-only registry using the template's catalog and approved configuration.       |
| `app/link/[...slug]/route.ts`   | Dynamic HTTP route; delegates to LinkMask's explicit 302 handler.                   |
| `components/affiliate-link.tsx` | Replacement component with optional `maskedSlug`; preserves consent and disclosure. |

For PowerShell, the exact copy commands are:

```powershell
$recipe = 'node_modules/@scttlnd/linkmask/examples/affiliatetemplate/src'
Copy-Item -LiteralPath "$recipe/lib/linkmask-paths.ts" -Destination 'src/lib/linkmask-paths.ts'
Copy-Item -LiteralPath "$recipe/lib/linkmask-registry.ts" -Destination 'src/lib/linkmask-registry.ts'
New-Item -ItemType Directory -Force -Path 'src/app/link/[...slug]' | Out-Null
Copy-Item -LiteralPath "$recipe/app/link/[...slug]/route.ts" -Destination 'src/app/link/[...slug]/route.ts'
Copy-Item -LiteralPath "$recipe/components/affiliate-link.tsx" -Destination 'src/components/affiliate-link.tsx'
```

If you customized `AffiliateLink`, merge the example's `maskedSlug` prop and href
selection into your component. Unchanged callers continue to use the template's
existing URLs.

## Connect each button to its registered slug

Add this import to `src/components/offer-table.tsx`, `src/components/deals.tsx`
and `src/components/article-markdown.tsx`:

```tsx
import { maskSlug } from "@/lib/linkmask-paths";
```

In `OfferTable`, add one prop to the existing `AffiliateLink`:

```tsx
<AffiliateLink
  url={offer.url}
  affiliateUrl={offer.affiliateUrl}
  maskedSlug={maskSlug("offer", product.slug, offer.id)}
  demo={product.demo}
>
  Se hos butik <Icon name="arrow" size={16} />
</AffiliateLink>
```

In `Deals`, add the deal slug:

```tsx
<AffiliateLink
  url={d.url}
  affiliateUrl={d.affiliateUrl}
  maskedSlug={maskSlug("deal", d.id)}
  demo={d.demo}
>
  Se tilbud hos butik <Icon name="arrow" size={16} />
</AffiliateLink>
```

In `ArticleMarkdown`, update both the approved-program CTA and the product-offer
link. Its offer-table directive already uses the updated `OfferTable`.

```tsx
<AffiliateLink
  url={program.url}
  affiliateUrl={program.affiliateUrl}
  maskedSlug={maskSlug("program", program.id)}
>
  {directive.label}
</AffiliateLink>
```

```tsx
<AffiliateLink
  url={offer.url}
  affiliateUrl={offer.affiliateUrl}
  maskedSlug={maskSlug("offer", product.slug, offer.id)}
  demo={product.demo}
>
  Se hos {offer.merchant}
</AffiliateLink>
```

For optional banners, add this import to `src/components/banner.tsx`:

```tsx
import { maskedHref, maskSlug } from "@/lib/linkmask-paths";
```

Replace only `BannerContent`'s `destination` assignment:

```tsx
const destination =
  marketing && banner.affiliateUrl
    ? (maskedHref(maskSlug("banner", banner.id), banner.affiliateUrl) ??
      banner.affiliateUrl)
    : banner.url;
```

Keep the existing `BannerPlacement` consent expression
`state.decided && state.marketing`, image gate, `rel` and disclosure text.

## Registry and route behavior

- Product keys combine product slug and offer ID. Other keys use a deal, approved
  program or approved banner ID. Each ID gets an `i-` prefix, preserving IDs that
  start with `_` or `-`. Do not change IDs when only a tracking destination changes.
- The server reads `getCatalog()`, `getDeals()`, `getPrograms()` and the template's
  validated banner configuration. It omits demo products and deals, inactive deals,
  unsafe direct URLs and unsupported affiliate URLs. Conflicting destinations
  under one key fail instead of silently changing attribution.
- Unsupported legacy IDs fall back to the original consent-aware link. IDs must
  contain only ASCII letters, digits, `_` and `-`. Affiliate destinations must be
  absolute URLs beginning with `https://`, without whitespace, credentials or
  backslashes (`https:shop.example` is not supported); percent-encode
  non-ASCII characters when preparing source URLs. Client and server apply the
  same eligibility check. The destination string itself is never rewritten.
- LinkMask does not fetch a destination. GET and HEAD for a registered slug return
  302 with an empty body, `Cache-Control: no-store`, `X-Robots-Tag: noindex, nofollow`
  and `Referrer-Policy: no-referrer`. Unknown slugs return 404; other methods at a
  registered slug return 405. Incoming query parameters cannot select a
  destination or modify affiliate attribution.
- `NEXT_PUBLIC_BASE_PATH` is respected in button hrefs, including subdirectory
  paths supported by the template. The handler awaits Next's route parameters
  and builds an internal `/link/...` request, avoiding double application of the
  deployment prefix. Do not replace the core response with Next's default
  `redirect()` helper, which uses a different status code.
- The registry follows the existing catalog's one-hour server cache; it does not
  add a second catalog cache. A removed offer or expired deal returns 404 on
  subsequent requests once the source data reflects that change. Update approved
  static configuration and redeploy to change program/banner URLs.

Keep `linkmask-registry.ts` server-only. Components import `linkmask-paths.ts`, which
depends on the package's browser-safe `/path` entry and never imports the registry.
This changes the visible link and redirect behavior; it is not encryption or
secret storage. Original affiliate URLs can still appear in the template's
hydrated props or configured banner/program data, and destinations remain visible
in HTTP responses and the browser's address bar after clicking. Existing
advertising disclosures and sponsored-link attributes remain in place.

Consent is selected by the template's client component. The redirect endpoint is
public and does not read the browser's local-storage preference. Shareable masked
links therefore redirect when opened directly; do not present this recipe as a
server-side consent enforcement mechanism.

## Verify the integration

Run the template's existing checks and server build:

```sh
npm run check
npm run build
npm start
```

With a configured approved program `merchant`, its slug is `program/i-merchant`.
Run this check against the running server, supplying that program's **exact**
configured affiliate destination as the last argument:

```sh
node node_modules/@scttlnd/linkmask/examples/affiliatetemplate/verify.mjs \
  http://localhost:3000 \
  program/i-merchant \
  'https://www.partner-ads.com/dk/klikbanner.php?partnerid=123&bannerid=456'
```

The example IDs above are placeholders, not program approvals. For a subdirectory
deployment, pass a site URL such as `http://localhost:3000/affiliatetemplate`.
The verification script never follows redirects or requests the merchant URL.
It checks GET/HEAD 302 status, the exact `Location`, response headers, query
override rejection, unknown-slug 404 and unsupported-method 405.

In a browser, verify that the button uses the direct URL before consent, changes
to the local `/link/...` URL after allowing affiliate tracking, and immediately
returns to the direct URL when privacy settings are reopened. Check persistence
after reload, demo buttons staying disabled, and optional banner image consent.
Clicking an enabled link should produce the same 302 checked by the script.

The recipe also includes automated helper and browser checks. Copy
`examples/affiliatetemplate/tests/linkmask.test.ts` to `tests/linkmask.test.ts` and
`examples/affiliatetemplate/tests/e2e/linkmask.spec.ts` to
`tests/e2e/linkmask.spec.ts` in your template, then run:

```sh
npm test
npx playwright install chromium
npx playwright test tests/e2e/linkmask.spec.ts --project desktop
```

The browser test bundles the real consent components, verifies hover paths and
reload/withdrawal behavior, and blocks outbound network requests. Existing
template tests omit `maskedSlug` and still exercise the original fallback.
CI copies the recipe into the pinned template, runs its checks and server build,
checks actual HTTP responses under `/affiliatetemplate`, and runs this browser test.
`tests/fixtures/programs.json` is only for that isolated CI checkout; do not
replace your real approved programs with this example fixture.

A fresh demo checkout intentionally has no live product redirects; use an
approved program or configured live feed when checking a successful redirect.
