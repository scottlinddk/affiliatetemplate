# Publish LinkMask to npm

The `Publish npm package` workflow in `.github/workflows/publish.yml` publishes
`@scttlnd/linkmask` to **npmjs.org** when you publish a stable GitHub release.
It runs the complete core and affiliate-template CI suite, validates version
metadata, packs an archive, uploads it as a workflow artifact, and publishes
that exact archive. A manually started workflow performs the same checks and
an npm dry run, but never publishes.

Package publication makes the files listed by `npm pack --dry-run` public. The
GitHub repository can stay private. The existing `UNLICENSED` designation is
preserved; publishing does not grant an open-source license.

## One-time npm setup

The npm account must own the `@scttlnd` scope or have permission to publish
there. The npm username is `scttlnd`; the GitHub owner is `scottlinddk`.
If the package does not exist yet, use an authenticated first publication
before setting up npm's trusted publisher. This workflow supports that first
publication through a temporary GitHub Actions secret:

1. Sign in to npm using the account with permission to create the package.
2. Create a short-lived granular access token with the permissions needed to
   create/publish this package in the scope, and **Bypass 2FA** for CI publishing.
3. In this GitHub repository's **Settings → Secrets and variables → Actions**,
   add the token as the repository secret **`NPM_TOKEN`**. Never commit it.
4. Publish the initial GitHub release as described below. The workflow uses the
   secret only in the actual publication step. A manual dry run does not require
   this secret and does not prove that publishing authentication is configured.

The package is not created by merging this workflow, making a tag alone, or
running a manual dry run. If you prefer an initial authenticated local
`npm publish`, the subsequent GitHub releases use the same setup below.

## Switch to npm trusted publishing

Once the package exists, open its settings on npmjs.org and add a trusted
publisher with these exact values:

| Setting | Value |
| --- | --- |
| Provider | GitHub Actions |
| Organization or user | `scottlinddk` |
| Repository | `LinkMask` |
| Workflow filename | `publish.yml` |
| Environment name | Leave empty |
| Allowed actions | Enable **Allow npm publish** |

New npm configurations can allow staged publication without permitting direct
`npm publish`; the direct-publish permission is required by this workflow.
It uses GitHub-hosted runners, Node 24, npm 11, and `id-token: write`. npm obtains
a short-lived token from GitHub's OIDC identity. Remove `NPM_TOKEN` after
configuring trusted publishing; subsequent releases need no stored npm token.

Provenance is disabled automatically while the source repository is private,
because npm does not support provenance for private source repositories. If the
repository becomes public, the workflow enables provenance automatically.

See npm's [trusted-publishing instructions](https://docs.npmjs.com/trusted-publishers/)
and [trust prerequisites](https://docs.npmjs.com/cli/v11/commands/npm-trust/).

## Validate without publishing

Open **Actions → Publish npm package → Run workflow** and select `main`.
The run must pass the core and Next.js integration checks, release metadata
validation, packaging and `npm publish --dry-run`. Download its
`npm-package-<commit>` artifact to inspect or install the `.tgz` file.

For local checks:

```sh
npm ci
npm run check
npm run check:release
npm pack --dry-run
```

## Publish a version

Use a tag matching the version in `package.json` and `package-lock.json`.
The first npm publication uses `1.0.1` / `v1.0.1`: the earlier GitHub `v1.0.0`
release could not publish under the previous npm scope. Its tag remains intact.
For later releases, bump both files in a PR:

```sh
npm version patch --no-git-tag-version
```

Merge the version change into `main` after CI passes. In **Releases → Draft a new
release**, create the matching `v<version>` tag from that main commit, write the
release notes, and publish it as a stable release. Publishing the release starts
the npm workflow; creating an unpublished draft or pushing a tag alone does not.

The workflow rejects mismatched versions/tags, a stale lockfile, an unexpected
registry, and a release commit outside `main`. Prereleases are skipped; only
stable versions are published under npm's default `latest` tag. Runs are
serialized to avoid overlapping publication attempts.

On success, consumers can use `npm install @scttlnd/linkmask`. Check the
published version with:

```sh
npm view @scttlnd/linkmask version
```

If a run fails before publishing, fix its cause and rerun it. If npm already
accepted the version, verify that version rather than attempting to overwrite it;
npm versions are immutable, so changed package contents need a new version.
