const SLUG = /^[A-Za-z0-9][A-Za-z0-9_-]*(?:\/[A-Za-z0-9][A-Za-z0-9_-]*)*$/;

/** Browser-safe: contains no destination registry or Node dependencies. */
export function linkPath(slug, prefix = '/link') {
  if (typeof slug !== 'string' || !SLUG.test(slug)) {
    throw new TypeError('Slugs must contain slash-separated letters, numbers, hyphens or underscores.');
  }
  if (typeof prefix !== 'string' || !prefix.startsWith('/') || !SLUG.test(prefix.slice(1))) {
    throw new TypeError('The prefix must be an absolute path such as /link or /shop/link, without a trailing slash.');
  }
  return `${prefix}/${slug}`;
}
