import { createServer } from 'node:http';
import { createLinkMask } from './index.js';

/** Create a Node HTTP server. Call .listen() to start serving redirects. */
export function createLinkMaskServer(links, options) {
  const linkMask = createLinkMask(links, options);

  return createServer(async (incoming, outgoing) => {
    try {
      if (!incoming.url.startsWith('/') || incoming.url.startsWith('//')) {
        outgoing.writeHead(404, { 'Cache-Control': 'no-store' });
        outgoing.end();
        return;
      }

      // The incoming Host header is never used to construct redirect URLs.
      const request = new Request(`http://localhost${incoming.url}`, {
        // Request forbids verbs such as TRACE. All unsupported verbs are
        // equivalent to POST here: 405 for known links, 404 for unknown ones.
        method: incoming.method === 'GET' || incoming.method === 'HEAD' ? incoming.method : 'POST',
      });
      const response = linkMask.handle(request);
      const body = Buffer.from(await response.arrayBuffer());
      outgoing.writeHead(response.status, Object.fromEntries(response.headers));
      outgoing.end(incoming.method === 'HEAD' ? undefined : body);
    } catch {
      outgoing.writeHead(500, {
        'Cache-Control': 'no-store',
        'Content-Type': 'text/plain; charset=utf-8',
      });
      outgoing.end(incoming.method === 'HEAD' ? undefined : 'Internal Server Error');
    }
  });
}
