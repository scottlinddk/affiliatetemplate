/** Build a same-origin path without importing any destination data. */
export declare function linkPath(slug: string, prefix?: string): string;
