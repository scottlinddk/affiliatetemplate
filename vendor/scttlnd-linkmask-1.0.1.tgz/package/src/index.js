import { linkPath } from './path.js';

export { linkPath } from './path.js';

/** Configure on the server. Requests can select a slug, never a destination. */
export function createLinkMask(links, { prefix = '/link' } = {}) {
  linkPath('validate-prefix', prefix);
  if (!links || typeof links !== 'object' || Array.isArray(links)) {
    throw new TypeError('Links must be an object mapping slugs to absolute HTTP(S) URLs.');
  }

  const destinations = new Map();
  for (const [slug, destination] of Object.entries(links)) {
    const path = linkPath(slug, prefix);
    let url;
    try {
      // ASCII URLs are safe in HTTP headers. Keep the original string so signed
      // queries, percent escapes, parameter order and fragments remain intact.
      if (typeof destination !== 'string' || !/^https?:\/\//i.test(destination) ||
          /[^\x21-\x7e]|\\/.test(destination)) throw new Error();
      url = new URL(destination);
      if (!url.hostname || url.username || url.password) throw new Error();
    } catch {
      throw new TypeError(`Invalid destination for "${slug}": use an absolute HTTP(S) URL without credentials or whitespace; percent-encode non-ASCII characters.`);
    }
    destinations.set(path, destination);
  }

  return {
    href: (slug) => linkPath(slug, prefix),
    handle(request) {
      const headers = {
        'Cache-Control': 'no-store',
        'X-Robots-Tag': 'noindex, nofollow',
        'Referrer-Policy': 'no-referrer',
      };
      // URL.pathname excludes the query, which must never override or modify a
      // configured affiliate destination. Allow one optional trailing slash.
      const path = new URL(request.url).pathname.replace(/\/$/, '');
      const destination = destinations.get(path);
      if (!destination) return new Response(null, { status: 404, headers });
      if (request.method !== 'GET' && request.method !== 'HEAD') {
        return new Response(null, { status: 405, headers: { ...headers, Allow: 'GET, HEAD' } });
      }
      return new Response(null, {
        status: 302,
        headers: { ...headers, Location: destination },
      });
    },
  };
}
