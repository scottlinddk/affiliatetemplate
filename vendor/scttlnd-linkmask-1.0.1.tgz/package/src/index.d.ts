export { linkPath } from './path.js';

export interface LinkMaskOptions {
  /** Same-origin mount path. Default: /link. No trailing slash. */
  prefix?: string;
}

export interface LinkMask {
  href(slug: string): string;
  handle(request: Request): Response;
}

/** Validates and snapshots a server-owned registry. Never accepts a target from a request. */
export declare function createLinkMask(
  links: Record<string, string>,
  options?: LinkMaskOptions,
): LinkMask;
