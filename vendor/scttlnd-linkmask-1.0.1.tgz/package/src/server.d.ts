import type { Server } from 'node:http';
import type { createLinkMask } from './index.js';

/** Create a Node HTTP server without opening a listening socket. */
export declare function createLinkMaskServer(
  links: Parameters<typeof createLinkMask>[0],
  options?: Parameters<typeof createLinkMask>[1],
): Server;
